# Sandwich shop

### This program calculates how much money a sandwich shop loses based on:

1. Sandwich holder type (stack or queue)

2. Number of holders

3. Customer order chance

4. How many sandwiches are made at once

5. How often new batches are made

6. How long sandwiches stay fresh

7. Sandwich price

8. Length of the workday

## Holder Types:  
### Stack:
New sandwiches go on top, customers get the newest one first.

### Queue:
New sandwiches go on top, customers get the oldest one first.

## Usage
To run the program
```bash
$ make
$ ./test.exe
```

## Credit
**krno1352** - made the stack library
**best1188** - made the stack library
