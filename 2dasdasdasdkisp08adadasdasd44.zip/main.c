#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int isValidGroup(int group[], int required_sum) {
    int sum = group[0] + group[1] + group[2];
    return sum == required_sum;
}

int backtrack(int nums[], int n, int used[], int groups[][3], int group_index, int required_sum) {
    if (group_index == n / 3)
        return 1;

    for (int i = 0; i < n; ++i) {
        if (used[i])
            continue;
        if (nums[i] > required_sum / 3)
            break;
        if (i > 0 && nums[i] == nums[i-1] && !used[i-1])
            continue;

        groups[group_index][0] = nums[i];
        used[i] = 1;

        for (int j = i + 1; j < n; ++j) {
            if (used[j])
                continue;
            if (nums[j] > (required_sum - nums[i]) / 2)
                break;
            if (j > i + 1 && nums[j] == nums[j-1] && !used[j-1])
                continue;

            groups[group_index][1] = nums[j];
            used[j] = 1;

            int target = required_sum - nums[i] - nums[j];

            for (int k = j + 1; k < n; ++k) {
                if (nums[k] > target)
                    break;
                if (!used[k] && nums[k] == target) {
                    groups[group_index][2] = nums[k];
                    used[k] = 1;

                    if (backtrack(nums, n, used, groups, group_index + 1, required_sum))
                        return 1;

                    used[k] = 0;
                }
            }

            used[j] = 0;
        }

        used[i] = 0;
        while (i + 1 < n && nums[i] == nums[i+1])
            i++;
    }

    return 0;
}

int canPartition(int nums[], int n, int groups[][3]) {
    if (n % 3 != 0)
        return 0;

    int total_sum = 0;
    for (int i = 0; i < n; ++i)
        total_sum += nums[i];

    if (total_sum % (n / 3) != 0)
        return 0;

    int required_sum = total_sum / (n / 3);

    qsort(nums, n, sizeof(int), compare);

    int used[n];
    for (int i = 0; i < n; ++i)
        used[i] = 0;

    return backtrack(nums, n, used, groups, 0, required_sum);
}

void run_test_case(int nums[], int n, const char* name) {
    printf("=== Test Case: %s ===\n", name);
    
    if (n < 3) {
        printf("Array must contain at least 3 elements.\n\n");
        return;
    }
    
    if (n % 3 != 0) {
        printf("Array length must be divisible by 3.\n\n");
        return;
    }

    double average = 0;
    for (int i = 0; i < n; ++i)
        average += nums[i];
    average = (double)(average / (n / 3));

    printf("Average sum per group: %f\n", average);

    int groups[n / 3][3];

    if (canPartition(nums, n, groups)) {
        printf("Yes, can be partitioned.\n");
        printf("Groups:\n");
        for (int i = 0; i < n / 3; ++i) {
            printf("(%d, %d, %d)\n", groups[i][0], groups[i][1], groups[i][2]);
        }
    } else {
        printf("No, cannot be partitioned.\n");
    }
    
    printf("\n");
}

int main() {
    int nums1[] = {1, 5, 6, 2, 8, 2, 4, 4, 4};
    run_test_case(nums1, sizeof(nums1)/sizeof(nums1[0]), "Test Case 1");
    
    int nums2[] = {3, 6, 9, 2, 7, 5, 4, 8, 1};
    run_test_case(nums2, sizeof(nums2)/sizeof(nums2[0]), "Test Case 2");
    
    int nums3[] = {130, 40, 70, 120, 50, 70, 110, 60, 70, 100, 90, 50};
    run_test_case(nums3, sizeof(nums3)/sizeof(nums3[0]), "Test Case 3");
    
    int nums4[] = {30, 40, 30, 25, 35, 40, 10, 45, 45, 20, 50, 30, 33, 33, 34};
    run_test_case(nums4, sizeof(nums4)/sizeof(nums4[0]), "Test Case 4 (Invalid length)");
    
    int nums5[] = {103, 3, 5, 53, 36, 22, 15, 64, 32, 109, 1, 1, 47, 30, 34, 61, 3, 47, 32, 57, 22};
    run_test_case(nums5, sizeof(nums5)/sizeof(nums5[0]), "Test Case 5 (Invalid length)");
    
    int edge1[] = {1, 1, 1, 1, 1, 1};
    run_test_case(edge1, sizeof(edge1)/sizeof(edge1[0]), "Edge Case 1 (All same)");
    
    int edge2[] = {1, 2, 3, 4, 5, 6};
    run_test_case(edge2, sizeof(edge2)/sizeof(edge2[0]), "Edge Case 2 (Consecutive)");
    
    int edge3[] = {10};
    run_test_case(edge3, sizeof(edge3)/sizeof(edge3[0]), "Edge Case 3 (Too short)");
    
    int edge4[] = {2, 2, 2, 3, 3, 3, 4, 4, 4};
    run_test_case(edge4, sizeof(edge4)/sizeof(edge4[0]), "Edge Case 4 (Multiple groups possible)");

    return 0;
}
