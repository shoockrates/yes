#ifndef SANDWICH_SHOP_H
#define SANDWICH_SHOP_H

#include <stdlib.h>

#include "queue.h"
#include "stack.h"

#include <stdio.h>

int find_shop_loss_stack(int holder_count, int order_chance, int sandwich_count, int sandwich_period, int expiration_time, int sandwich_price, int day_length);
void insert_sandwiches_stack(Stack *holders[], int holder_count, int sandwich_count, int time);
void buy_sandwich_stack(Stack *holders[], int holder_count);

int find_shop_loss_queue(int holder_count, int order_chance, int sandwich_count, int sandwich_period, int expiration_time, int sandwich_price, int day_length);
void insert_sandwiches_queue(Queue *holders[], int holder_count, int sandwich_count, int time);
void buy_sandwich_queue(Queue *holders[], int holder_count);

#endif //SANDWICH_SHOP_H
