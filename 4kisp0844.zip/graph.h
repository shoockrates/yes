struct Graph
{
	int size;
	int** nodes;
	int* adj_sizes;
};

typedef struct Graph Graph;

Graph* create_graph(int size);

int add_edge(Graph* g, int a, int b);

int dfs_inner(Graph* g, int* visited, int from, int to);

int dfs(Graph* g, int from, int to);

void clear_graph(Graph* g);