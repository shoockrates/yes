#ifndef QUEUE_H
#define QUEUE_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef int data_type;

typedef struct {
  data_type *array;
  size_t size;
  size_t capacity;
} Queue;

Queue *create_queue();
int enqueue(Queue *queue, data_type data);
int dequeue(Queue *queue);
data_type peek(Queue *queue);  // return the first element without removing it
int is_empty(Queue *queue);
int is_full(Queue *queue);
int free_queue(Queue *queue);
size_t queue_size(Queue *queue);
size_t queue_capacity(Queue *queue);

#endif