#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "graph.h"
#include "map.h"
#define MAX_NAME_LENGTH 255
void print_initial_data(Graph* g, map* mp, char* from, char* to, int M)
{
	printf("------------------------\n");
	printf("-  Pradiniai duomenys  -\n");
	printf("------------------------\n\n");
	printf("Padaryta %d paslaugos(-ų), jų sąraše yra %d skirtingi(-ų) žmonės(-ių).\n", M, mp->size);
	printf("Padarytų paslaugų sąrašas:\n\n");
	printf("    Žmogaus vardas    |    Kuriems žmonėms padarė paslaugą   \n");
	printf("-------------------------------------------------------------\n");
	for(int i=0; i<mp->size; ++i)
	{
		printf(" %20s | ",mp->names[i]);
		for(int j=0; j<(g->adj_sizes[i]); ++j)
		{
			printf("%s%s", get_name(mp,g->nodes[i][j]), ((j==(g->adj_sizes[i])-1) ? "" : ", "));
		}
		printf("\n");
	}
	printf("\nNorime sužinoti, ar už padarytas paslaugas %s gali tikėtis pasiskolinti pinigų iš %s.\n\n", from, to);
	printf("---------------------------------------------------------------------------------------------\n\n");
	return;
}
int main(int argc, char** argv)
{
	int N = 0;
	int M = 0;
	char* name1 = (char*)malloc(MAX_NAME_LENGTH*sizeof(char));
	char* name2 = (char*)malloc(MAX_NAME_LENGTH*sizeof(char));
	if(argc != 2)
	{
		fprintf(stderr, "Usage: %s [input_file|-preset]\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	else // argc == 2
	{
		if(strcmp(argv[1],"-preset") == 0)
		{
			N = 5;
			M = 7;
			name1 = "Alice";
			name2 = "Bob";
			Graph* g = create_graph(N);
			map* mp = create_map(N);
			add_name(mp,"Alice");
			add_name(mp,"Bob");
			add_name(mp,"Charlie");
			add_name(mp,"David");
			add_name(mp,"Eve");
			add_edge(g,get_id(mp,"Alice"),get_id(mp,"David"));
			add_edge(g,get_id(mp,"David"),get_id(mp,"Alice"));
			add_edge(g,get_id(mp,"Alice"),get_id(mp,"Eve"));
			add_edge(g,get_id(mp,"Alice"),get_id(mp,"Charlie"));
			add_edge(g,get_id(mp,"Charlie"),get_id(mp,"Eve"));
			add_edge(g,get_id(mp,"Charlie"),get_id(mp,"Bob"));
			add_edge(g,get_id(mp,"Bob"),get_id(mp,"Eve"));
			
			int node1 = get_id(mp, name1);
			int node2 = get_id(mp, name2);
			
			print_initial_data(g,mp,name1,name2,M);
			
			if(dfs(g,node1,node2)==1)
			{
				printf("TAIP, %s gali tikėtis gauti pinigų iš %s\n\n", name1, name2);
				clear_graph(g);
				return 0;
			}
			printf("NE, %s negali tikėtis iš %s gauti pinigų\n\n", name1, name2);
			clear_graph(g);
			return 0;
		}
		char* file_name = argv[1];
		FILE* input = fopen(file_name,"r");
		if(input == NULL)
		{
			fprintf(stderr, "Error: could not open the file '%s'\n", file_name);
			exit(EXIT_FAILURE);
		}
		if(fscanf(input,"%d",&N)!=1)
		{
			fprintf(stderr, "Error: Incorrect input formatting. See the Testing/Formatting sections of the ReadMe.md file for the correct input format.\n");
			fclose(input);
			exit(EXIT_FAILURE);
		}
		if(fscanf(input,"%d",&M)!=1)
		{
			fprintf(stderr, "Error: Incorrect input formatting. See the Testing/Formatting sections of the ReadMe.md file for the correct input format.\n");
			fclose(input);
			exit(EXIT_FAILURE);
		}
		if(N<1)
		{
			fprintf(stderr, "Error: N must be a positive integer.\n");
			fclose(input);
			exit(EXIT_FAILURE);
		}
		if(M<0)
		{
			fprintf(stderr, "Error: M must be a nonnegative integer.\n");
			fclose(input);
			exit(EXIT_FAILURE);
		}
		
		Graph* g = create_graph(N);
		map* mp = create_map(N);
		if(fscanf(input,"%s %s\n",name1,name2)!=2)
		{
			fprintf(stderr, "Error: Incorrect input formatting. See the Testing/Formatting sections of the ReadMe.md file for the correct input format.\n");
			clear_graph(g);
			clear_map(mp);
			fclose(input);
			exit(EXIT_FAILURE);
		}
		
		for(int i=0; i<M; ++i)
		{
			char* u = (char*)malloc(MAX_NAME_LENGTH*sizeof(char));
			char* v = (char*)malloc(MAX_NAME_LENGTH*sizeof(char));
			if(fscanf(input,"%s %s",u,v)!=2)
			{
				fprintf(stderr, "Error: Incorrect input formatting. See the Testing/Formatting sections of the ReadMe.md file for the correct input format.\n");
				clear_graph(g);
				clear_map(mp);
				fclose(input);
				exit(EXIT_FAILURE);
			}
			if(get_id(mp,u)==-1)
			{
				if(add_name(mp,u)==0)
				{
					fprintf(stderr, "Error: Invalid input. The number of distinct names is greater than the number N specified in the first line.\n");
					clear_graph(g);
					clear_map(mp);
					fclose(input);
					exit(EXIT_FAILURE);
				}
			}
			if(get_id(mp,v)==-1)
			{
				if(add_name(mp,v)==0)
				{
					fprintf(stderr, "Error: Invalid input. The number of distinct names is greater than the number N specified in the first line.\n");
					clear_graph(g);
					clear_map(mp);
					fclose(input);
					exit(EXIT_FAILURE);
				}
			}
			add_edge(g,get_id(mp,u),get_id(mp,v));
		}
		
		if(get_id(mp,name1)==-1)
		{
			if(add_name(mp,name1)==0)
			{
				fprintf(stderr, "Error: Invalid input. The number of distinct names is greater than the number N specified in the first line.\n");
				clear_graph(g);
				clear_map(mp);
				fclose(input);
				exit(EXIT_FAILURE);
			}
		}
		if(get_id(mp,name2)==-1)
		{
			if(add_name(mp,name2)==0)
			{
				fprintf(stderr, "Error: Invalid input. The number of distinct names is greater than the number N specified in the first line.\n");
				clear_graph(g);
				clear_map(mp);
				fclose(input);
				exit(EXIT_FAILURE);
			}
		}
		
		int node1 = get_id(mp, name1);
		int node2 = get_id(mp, name2);
		
		print_initial_data(g,mp,name1,name2,M);
		
		if(dfs(g,node1,node2)==1)
		{
			printf("TAIP, %s gali tikėtis gauti pinigų iš %s\n\n", name1, name2);
			clear_graph(g);
			clear_map(mp);
			free(name1);
			free(name2);
			return 0;
		}
		printf("NE, %s negali tikėtis iš %s gauti pinigų\n\n", name1, name2);
		clear_graph(g);
		clear_map(mp);
		free(name1);
		free(name2);
		return 0;
	}
	return 0;
}