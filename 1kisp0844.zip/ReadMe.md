# 4. ADT – Prioritetinė eilė (A)

## Projekto struktūra:

- **main.c** - testavimo programa, išbandanti visas sukurtas funkcijas.
- **priority_queue.c** - funkcijų, skirtų darbui su dvejetainiu paieškos medžiu, įgyvendinimas.
- **priority_queue.h** - duomenų tipų ir funkcijų aprašymas.
- **go.cmd** - paleidimo programa, kuri sukompiliuoja programą tiek asmeniniame kompiuteryje, tiek fakulteto kompiuteryje, bei paleidžia programą.
- **LFF.xlsx** - dokumentas su laiko fiksavimo forma.
- **makefile** - sukompiliuoja programą.
- **ReadMe.md** - trumpas pirmojo laboratorinio darbo aprašas.

## Paleidimas
Norint paleisti testo kodą, paleiskite **go.cmd** failą.