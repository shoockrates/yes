#include "partition.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

static int isValidGroup(int group[], int required_sum) {
    return (group[0] + group[1] + group[2]) == required_sum;
}

static int backtrack(int nums[], int n, int used[], int groups[][3], int group_index, int required_sum) {
    if (group_index == n / 3) return 1;

    for (int i = 0; i < n; ++i) {
        if (used[i]) continue;
        if (nums[i] > required_sum / 3) break;
        if (i > 0 && nums[i] == nums[i-1] && !used[i-1]) continue;

        groups[group_index][0] = nums[i];
        used[i] = 1;

        for (int j = i + 1; j < n; ++j) {
            if (used[j]) continue;
            if (nums[j] > (required_sum - nums[i]) / 2) break;
            if (j > i + 1 && nums[j] == nums[j-1] && !used[j-1]) continue;

            groups[group_index][1] = nums[j];
            used[j] = 1;
            int target = required_sum - nums[i] - nums[j];

            for (int k = j + 1; k < n; ++k) {
                if (nums[k] > target) break;
                if (!used[k] && nums[k] == target) {
                    groups[group_index][2] = nums[k];
                    used[k] = 1;
                    if (backtrack(nums, n, used, groups, group_index + 1, required_sum)) return 1;
                    used[k] = 0;
                }
            }
            used[j] = 0;
        }
        used[i] = 0;
        while (i + 1 < n && nums[i] == nums[i+1]) i++;
    }
    return 0;
}

int canPartition(int nums[], int n, int groups[][3]) {
    if (n % 3 != 0) return 0;

    int total_sum = 0;
    for (int i = 0; i < n; ++i) total_sum += nums[i];
    if (total_sum % (n / 3) != 0) return 0;

    int required_sum = total_sum / (n / 3);
    qsort(nums, n, sizeof(int), compare);

    int used[n];
    for (int i = 0; i < n; ++i) used[i] = 0;

    return backtrack(nums, n, used, groups, 0, required_sum);
}

void run_test_case(int nums[], int n, const char* name) {
    printf("=== Test Case: %s ===\n", name);
    if (n < 3) {
        printf("Array must contain at least 3 elements.\n\n");
        return;
    }
    if (n % 3 != 0) {
        printf("Array length must be divisible by 3.\n\n");
        return;
    }

    double average = 0;
    for (int i = 0; i < n; ++i) average += nums[i];
    average /= (n / 3);
    printf("Average sum per group: %f\n", average);

    int groups[n/3][3];
    if (canPartition(nums, n, groups)) {
        printf("Yes, can be partitioned.\nGroups:\n");
        for (int i = 0; i < n / 3; ++i)
            printf("(%d, %d, %d)\n", groups[i][0], groups[i][1], groups[i][2]);
    } else {
        printf("No, cannot be partitioned.\n");
    }
    printf("\n");
}