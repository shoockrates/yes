#include "sandwich_shop.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define HLINE "╠═══════════════════╪════════╣"
#define LASTLINE "╚═══════════════════╧════════╝"

void print_header() {
    printf("\n");
    printf("    SANDWICH SHOP SIMULATOR \n");
    printf("\n");
    printf("╔══════════════════════════════╗\n");
    printf("║        CONFIGURATION         ║\n");
    printf("╠══════════════════╦═══════════╣\n");
    printf("║ Order chance     ║ %5d%%    ║\n", 5);
    printf("║ Sandwich count   ║ %5d     ║\n", 50);
    printf("║ Sandwich period  ║ %5d sec ║\n", 125);
    printf("║ Expiration time  ║ %5d sec ║\n", 600);
    printf("║ Sandwich price   ║ $%4d     ║\n", 2);
    printf("║ Day length       ║ %5d sec ║\n", 1200);
    printf("╚══════════════════╩═══════════╝\n");
    printf("\n");
}

void print_results_row(const char* label, int loss) {
    printf("║ %-17s ║ $%5d ║\n", label, loss);
}

int main(void) {
    time_t current_time = time(NULL);
    srand((unsigned int)current_time);

    const int order_chance = 5;
    const int sandwich_count = 50;
    const int sandwich_period = 125;
    const int expiration_time = 600;
    const int sandwich_price = 2;
    const int day_length = 1200;

    print_header();

    printf("╔═══════════════════╦════════╗\n");
    printf("║ Holder Type       ║ Losses ║\n");
    printf(HLINE);
    printf("\n");


    print_results_row("2 Stack Holders", 
        find_shop_loss_stack(2, order_chance, sandwich_count, 
                            sandwich_period, expiration_time, 
                            sandwich_price, day_length));
    printf(HLINE);
    printf("\n");

    print_results_row("1 Queue Holder", 
        find_shop_loss_queue(1, order_chance, sandwich_count, 
                           sandwich_period, expiration_time, 
                           sandwich_price, day_length));
    printf(HLINE);
    printf("\n");

    print_results_row("2 Queue Holders", 
        find_shop_loss_queue(2, order_chance, sandwich_count, 
                           sandwich_period, expiration_time, 
                           sandwich_price, day_length));
    printf(LASTLINE);
    printf("\n");

    printf("Key:\n");
    printf("  Stack: Last-In-First-Out holders\n");
    printf("  Queue: First-In-First-Out holders\n");
    printf("\n");

    return 0;
}