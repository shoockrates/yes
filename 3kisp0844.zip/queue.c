#include "queue.h"
#define MIN_SIZE 8

size_t queue_memory_size(size_t current_size) {
  size_t min_size = MIN_SIZE;
  if (current_size < min_size) {
    return min_size;
  }
  size_t new_size = current_size * 2;
  if (new_size < current_size) {
    return current_size;
  }
  return new_size;
}


Queue *create_queue() {
  Queue *queue = (Queue *)malloc(sizeof(Queue));
  queue->capacity = queue_memory_size(0);
  queue->array = (data_type *)malloc(sizeof(data_type) * queue->capacity);
  queue->size = 0;
  
  return queue;
}

int enqueue(Queue *queue, data_type data) {
  if (queue->size == queue->capacity) {
    size_t new_capacity = queue_memory_size(queue->capacity);
    data_type *new_array = (data_type *)realloc(queue->array, sizeof(data_type) * new_capacity);
    if (new_array == NULL) {
      return 0;
    }
    queue->array = new_array;
    queue->capacity = new_capacity;
  }
  queue->array[queue->size] = data;
  queue->size++;
  return 1;
}

int dequeue(Queue *queue) {
  if (queue->size == 0) {
    return 0;
  }
  for (size_t i = 0; i < queue->size - 1; i++) {
    queue->array[i] = queue->array[i + 1];
  }
  queue->size--;
  return 1;
}
  
data_type peek(Queue *queue) {
  if (queue->size == 0) {
    data_type empty_data = 0; 
    return empty_data;
  }
  return queue->array[0];
}

int free_queue(Queue *queue) {
  free(queue->array);
  free(queue);
  return 1;
}

int is_empty(Queue *queue) {
  return queue->size == 0;
}

int is_full(Queue *queue) {
  return queue->size == queue->capacity;
}

size_t queue_size(Queue *queue) {
  return queue->size;
} 

size_t queue_capacity(Queue *queue) {
  return queue->capacity;
} 