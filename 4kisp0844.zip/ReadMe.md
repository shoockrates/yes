# Grafai: Galimybė gauti pinigų pagal suteiktas paslaugas

## Problemos Apibrėžimas

Duotas sąrašas nukreiptų paslaugų sąryšių tarp žmonių (kas kam yra padaręs paslaugą). Gali būti situacijų, kad du žmonės yra padarę abipuses paslaugas vienas kitam.
Galimybė gauti pinigų apibrėžiama taip: jei žmogus `A` padarė paslaugą žmogui `B`, tai `A` turi teisę tikėtis gauti pinigų ne tik iš `B`, bet ir iš visų, kuriems `B` padarė paslaugą. Ši teisė yra "persiduodanti" toliau paslaugų grandinėje. Pavyzdžiui, jei `A` padarė paslaugą `B` (A -> B), o `B` padarė paslaugą `C` (B -> C), tai `A` gali tikėtis pinigų tiek iš `B`, tiek iš `C` (nes C gavo paslaugą iš B, kuriam paslaugą padarė A). Apibendrintai, jei egzistuoja paslaugų grandinė nuo `A` iki `B` (t. y., A padarė paslaugą X1, X1 padarė paslaugą X2, ..., Xk padarė paslaugą B), tai `A` gali tikėtis gauti pinigų iš `B`.

Uždavinys - patikrinti, ar duotas konkretus žmogus `V1` gali tikėtis gauti pinigų iš kito konkretaus žmogaus `V2`, remiantis pateiktais paslaugų sąryšiais ir apibrėžta pinigų gavimo taisykle.

## Sprendimas ir Algoritmas

Norint patikrinti, ar žmogus `V1` gali tikėtis gauti pinigų iš žmogaus `V2`, modeliuojame paslaugų sąryšius kaip nukreiptąjį grafą. Grafo viršūnės atitinka žmones. Nukreipta briauna iš viršūnės `A` į viršūnę `B` egzistuoja tada ir tik tada, kai žmogus `A` padarė paslaugą žmogui `B`.

Remiantis problemos apibrėžimu, žmogus `V1` gali tikėtis gauti pinigų iš žmogaus `V2` tada ir tik tada, jei sukurtame grafe egzistuoja pasiekiamas kelias iš viršūnės `V1` į viršūnę `V2`.

Šiam pasiekiamumo patikrinimui atlikti naudojamas paieškos į gylį (DFS - Depth-First Search) algoritmas. Pradedame paiešką nuo viršūnės, atitinkančios žmogų `V1`. DFS algoritmas sistemingai aplanko visas viršūnes, pasiekiamas iš pradinės viršūnės, sekdamas nukreiptas briaunas.

*   Jei DFS paieškos metu pasiekiame viršūnę, atitinkančią žmogų `V2`, tai reiškia, kad egzistuoja kelias iš `V1` į `V2`, ir `V1` gali tikėtis pinigų iš `V2`. Tokiu atveju paiešką galima nutraukti ir pateikti teigiamą atsakymą.
*   Jei DFS algoritmas užbaigia darbą (aplanko visas iš `V1` pasiekiamas viršūnes) ir viršūnė, atitinkanti žmogų `V2`, nebuvo pasiekta, tai reiškia, kad kelias iš `V1` į `V2` neegzistuoja, ir `V1` neturėtų tikėtis gauti pinigų iš `V2`. Pateikiamas neigiamas atsakymas.

Algoritmo sudėtingumas (laiko atžvilgiu) yra O(V + E), kur V yra žmonių (grafo viršūnių) skaičius, o E - paslaugų sąryšių (grafo briaunų) skaičius. Erdvinis sudėtingumas priklauso nuo grafo realizacijos (pvz., kaimynystės sąrašų atveju O(V + E), kaimynystės matricos atveju O(V²)).

## Panaudotos Duomenų Struktūros ir Bibliotekos

**Panaudotos Duomenų Struktūros (ADT - Abstract Data Types):**
Projekto implementacijoje buvo sukurtos ir panaudotos šios savos duomenų struktūros:
*   **Nukreiptasis Grafas:** Realizacija paremta kaimynystės (adjacency) sąrašais. Ši struktūra saugo informaciją apie tai, kas kam padarė paslaugą, kaip nukreiptas briaunas.
*   **Žmonių vardų atvaizdis (Map):** Struktūra, skirta unikaliems žmonių vardams (simbolių eilutėms) priskirti unikalius sveikus skaičius (indeksus) ir atvirkščiai. Ši bijekcija leidžia efektyviai dirbti su grafu naudojant skaičių indeksus. Nurodoma, kad realizacija paremta masyvais.

**Panaudotos C standartinės bibliotekos:**
Implementacijoje panaudotos šios standartinės C programavimo kalbos bibliotekos:
*   `stdio.h`: Įvesties/išvesties operacijoms (pvz., skaitymui iš failo, spausdinimui rezultatų).
*   `stdlib.h`: Bendrojo pobūdžio funkcijoms (pvz., atminties paskirstymui, programos vykdymo valdymui).
*   `string.h`: Darbui su simbolių eilutėmis (pvz., vardų apdorojimui, lyginimui).

## Testavimas

**Programos paleidimas ir testavimas:**
Sukompiliuotą programą `test.exe` galima paleisti per komandinę eilutę, nurodant vieną iš šių argumentų:
*   `test.exe [failo_vardas]`: Nuskaito paslaugų sąryšių duomenis iš nurodyto failo.
*   `test.exe -preset`: Programa naudoja integruotą (iš anksto paruoštą) testavimo duomenų rinkinį.

**Testavimo rezultatas:**
Sėkmingai paleidus programą ir apdorojus duomenis, pirmiausia į standartinę išvestį išvedamas nuskaitomų (arba parengtų) duomenų apibendrinimas (pvz., bendras unikalių žmonių ir paslaugų skaičius, užklausa "ar V1 gali gauti pinigų iš V2?"). Po to pateikiamas galutinis atsakymas į užklausą -"TAIP" (jei V1 gali tikėtis pinigų iš V2) arba "NE" (priešingu atveju).

## Įvesties Failo Formatas

Duomenys nuskaitomi iš tekstinio failo. Įvesties failo formatas turi atitikti šias taisykles:
*   **Pirmoji eilutė:** Turi būti keturi elementai, atskirti bent vienu tarpo simboliu:
    1.  Teigiamas sveikasis skaičius `N`: Maksimalus galimas skirtingų žmonių vardų skaičius visame faile (grafo viršūnių limitas).
    2.  Neneigiamas sveikasis skaičius `M`: Tikslus paslaugų sąryšių skaičius, nurodytas sekančiose failo eilutėse.
    3.  Simbolių eilutė `V1`: Pirmojo žmogaus vardas (iš kurio klausiama, ar jis gali gauti pinigų).
    4.  Simbolių eilutė `V2`: Antrojo žmogaus vardas (iš kurio tikimasi pinigų).
*   **Sekančios `M` eilutės:** Kiekvienoje iš šių eilučių nurodomi du vardai, atskirti bent vienu tarpu (` `). Pavyzdžiui, "VardasA VardasB". Toks įrašas reiškia, kad žmogus `VardasA` padarė paslaugą žmogui `VardasB`. Tai grafe atitinka nukreiptą briauną `VardasA` -> `VardasB`.
*   Failo gale gali būti tuščių eilučių ar tarpų, bet neturi būti papildomų prasmingų duomenų ar įrašų.

**Pavyzdinė įvestis:**
```input.txt
4 5 A D
A B
A C
C D
B D
B C