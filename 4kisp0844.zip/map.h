struct map
{
	int cap;
	int size;
	char** names;
};

typedef struct map map;

map* create_map(int size);

int add_name(map* mp, char* name);

char* get_name(map* mp, int id);

int get_id(map* mp, char* name);

void clear_map(map* mp);