# 4. ADT – Prioritetinė eilė (A)

## Aprašymas
Ši biblioteka suteikia galimybę dirbti su prioritetų eilute.

## Struktūra

C

"""

typedef struct Node{
    int value;
    struct Node *next;
} Node;

typedef struct {
    Node *head;
    Node *tail;
    int size;
} Queue;
"""

## Projekto struktūra:

- **main.c** - testavimo programa, išbandanti visas sukurtas funkcijas.
- **priority_queue.c** - funkcijų, skirtų darbui su dvejetainiu paieškos medžiu, įgyvendinimas.
- **priority_queue.h** - duomenų tipų ir funkcijų aprašymas.
- **go.cmd** - paleidimo programa.
- **LFF.xlsx** - dokumentas su laiko fiksavimo forma.
- **makefile** - sukompiliuoja programą.
- **ReadMe.md** - trumpas pirmojo laboratorinio darbo aprašas.

## Paleidimas
Norint paleisti testo kodą, paleiskite **go.cmd** failą.