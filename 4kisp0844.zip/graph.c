#include<stdio.h>
#include<stdlib.h>
#include "graph.h"

Graph* create_graph(int size)
{
	if(size < 1)
	{
		return NULL;
	}
	Graph* new_graph = (Graph*)malloc(sizeof(Graph));
	if(new_graph == NULL)
	{
		return NULL;
	}
	new_graph->size = size;
	new_graph->nodes = (int**)malloc(size*sizeof(int*));
	if(new_graph->nodes == NULL)
	{
		free(new_graph);
		return NULL;
	}
	
	new_graph->adj_sizes = (int*)malloc(size*sizeof(int));
	if(new_graph->adj_sizes == NULL)
	{
		free(new_graph->nodes);
		free(new_graph);
		return NULL;
	}
	for(int i=0; i<size; ++i)
	{
		new_graph->nodes[i]=(int*)malloc(0*sizeof(int));
		new_graph->adj_sizes[i]=0;
		if(new_graph->nodes[i] == NULL)
		{
			for(int j=i-1; j>=0; j--)
			{
				free(new_graph->nodes[j]);
			}
			free(new_graph->nodes);
			free(new_graph->adj_sizes);
			free(new_graph);
			return NULL;
		}
	}
	return new_graph;
}

int add_edge(Graph* g, int a, int b)
{
	if((a >= (g->size)) || (b >= (g->size)) || (a < 0) || (b < 0))
	{
		return 0;
	}
	g->adj_sizes[a]++;
	g->nodes[a]=(int*)realloc(g->nodes[a],(g->adj_sizes[a])*sizeof(int));
	if(g->nodes[a] == NULL)
	{
		return -1;
	}
	g->nodes[a][(g->adj_sizes[a])-1]=b;
	return 1;
}

int dfs_inner(Graph* g, int* visited, int from, int to)
{
	if(visited[to]==1&&from==to)
	{
		return 1;
	}
	for(int i=0; i<g->adj_sizes[from]; ++i)
	{
		if(!visited[g->nodes[from][i]])
		{
			visited[g->nodes[from][i]]=1;
			if(dfs_inner(g,visited,g->nodes[from][i],to)==1)
			{
				return 1;
			}
		}
	}
	return 0;
}

int dfs(Graph* g, int from, int to)
{
	if((from >= (g->size)) || (to >= (g->size)) || (from < 0) || (to < 0))
	{
		return -1;
	}
	int* visited = (int*)malloc((g->size)*sizeof(int));
	for(int i=0; i<g->size; ++i)
	{
		visited[i]=0;
	}
	if(dfs_inner(g,visited,from,to)==1)
	{
		free(visited);
		return 1;
	}
	free(visited);
	return 0;
}

void clear_graph(Graph* g)
{
	if(g==NULL)
	{
		return;
	}
	for(int i=0; i<g->size; ++i)
	{
		free(g->nodes[i]);
	}
	free(g->nodes);
	free(g->adj_sizes);
	free(g);
	return;
}