#ifndef PARTITION_H
#define PARTITION_H

int canPartition(int nums[], int n, int groups[][3]);
void run_test_case(int nums[], int n, const char* name);

#endif