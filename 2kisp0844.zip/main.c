#include "partition.h"

int main() {
    int nums1[] = {1, 5, 6, 2, 8, 2, 4, 4, 4};
    run_test_case(nums1, sizeof(nums1)/sizeof(nums1[0]), "Test Case 1");
    
    int nums2[] = {3, 6, 9, 2, 7, 5, 4, 8, 1};
    run_test_case(nums2, sizeof(nums2)/sizeof(nums2[0]), "Test Case 2");
    
    int nums3[] = {130, 40, 70, 120, 50, 70, 110, 60, 70, 100, 90, 50};
    run_test_case(nums3, sizeof(nums3)/sizeof(nums3[0]), "Test Case 3");
    
    int nums4[] = {30, 40, 30, 25, 35, 40, 10, 45, 45, 20, 50, 30, 33, 33, 34};
    run_test_case(nums4, sizeof(nums4)/sizeof(nums4[0]), "Test Case 4 (Invalid length)");
    
    int nums5[] = {103, 3, 5, 53, 36, 22, 15, 64, 32, 109, 1, 1, 47, 30, 34, 61, 3, 47, 32, 57, 22};
    run_test_case(nums5, sizeof(nums5)/sizeof(nums5[0]), "Test Case 5 (Invalid length)");
    
    int edge1[] = {1, 1, 1, 1, 1, 1};
    run_test_case(edge1, sizeof(edge1)/sizeof(edge1[0]), "Edge Case 1 (All same)");
    
    int edge2[] = {1, 2, 3, 4, 5, 6};
    run_test_case(edge2, sizeof(edge2)/sizeof(edge2[0]), "Edge Case 2 (Consecutive)");
    
    int edge3[] = {10};
    run_test_case(edge3, sizeof(edge3)/sizeof(edge3[0]), "Edge Case 3 (Too short)");
    
    int edge4[] = {2, 2, 2, 3, 3, 3, 4, 4, 4};
    run_test_case(edge4, sizeof(edge4)/sizeof(edge4[0]), "Edge Case 4 (Multiple groups possible)");

    return 0;
}