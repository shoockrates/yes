#include <stdlib.h>
#include "stack.h"
#include <stdio.h>

//Create a new stack with an initial size
Stack* Stack_create(int capacity) {
    if (capacity <= 0) return NULL;
    Stack *stack = (Stack*) malloc(sizeof(Stack));
    if (!stack) return NULL;
    stack->data = (int*) malloc((unsigned long)capacity * sizeof(int));
    if (!stack->data) {
        free(stack);
        return NULL;
    }
    stack->top = -1;
    stack->capacity = capacity;
    return stack;
}

//Push an element onto the stack
bool Stack_push(Stack *stack, int value) {
    if (!stack) return false;
    if (stack->top == stack->capacity - 1) {
        int new_capacity = stack->capacity * 2;
        int *new_data = (int*) realloc(stack->data, (unsigned long) new_capacity * sizeof(int));
        if (!new_data) return false;
        stack->data = new_data;
        stack->capacity = new_capacity;
    }
    stack->data[++stack->top] = value;
    return true;
}

//Pop an element from the stack
int Stack_pop(Stack *stack, bool *success) {
    if (!stack || Stack_isEmpty(stack)) {
        if (success) *success = false;
        return -1; // Error value
    }
    if (success) *success = true;
    return stack->data[stack->top--];
}

//Check if the stack is empty
bool Stack_isEmpty(Stack *stack) {
    return stack && stack->top == -1;
}

//Get the number of elements in the stack
int Stack_count(Stack *stack) {
    return stack ? stack->top + 1 : 0;
}

//Free memory
void Stack_free(Stack *stack) {
    if (!stack) return;
    free(stack->data);
    free(stack);
}
