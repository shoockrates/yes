#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "map.h"

map* create_map(int size)
{
	if(size < 1)
	{
		return NULL;
	}
	map* new_map = (map*)malloc(sizeof(map));
	if(new_map == NULL)
	{
		return NULL;
	}
	new_map->cap = size;
	new_map->size = 0;
	
	new_map->names = (char**)malloc(size*sizeof(char*));
	if(new_map->names == NULL)
	{
		free(new_map);
		return NULL;
	}
	return new_map;
}

int add_name(map* mp, char* name)
{
	if((mp->size)>=(mp->cap))
	{
		return 0;
	}
	for(int i=0; i<(mp->size); ++i)
	{
		if(strcmp(mp->names[i],name)==0)
		{
			return 2;
		}
	}
	mp->names[mp->size]=name;
	mp->size++;
	return 1;
}

char* get_name(map* mp, int id)
{
	if(id<0||id>=(mp->size))
	{
		return "";
	}
	return mp->names[id];
}

int get_id(map* mp, char* name)
{
	for(int i=0; i<(mp->size); ++i)
	{
		if(strcmp(mp->names[i],name)==0)
		{
			return i;
		}
	}
	return -1;
}

void clear_map(map* mp)
{
	if(mp==NULL)
	{
		return;
	}
	for(int i=0; i<(mp->size); ++i)
	{
		free(mp->names[i]);
	}
	free(mp->names);
	free(mp);
	return;
}