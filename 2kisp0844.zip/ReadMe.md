
# **Trejetų Suskirstymas (Triplet Partitioning)**


## Užduotis
```
10. Ištirti, ar duotas skaičių rinkinys, gali būti išskirstytas į skaičių trejetus taip, kad skaičių visuose trejetuose suma būtų vienoda. Pvz.: {1,5,6,2,8,2,3,4,4} => (1,5,6), (2,8,2), (3,4,4)
```

## **Apžvalga:**
Šis C programos kodas tikrina, ar pateiktas sveikųjų skaičių masyvas gali būti suskirstytas į tripletus (trio), kurių suma yra vienoda. Programos tikslas - sugrupuoti skaičius į grupes po tris, taip, kad kiekvienos grupės suma būtų lygi.

## **Kaip tai veikia:**
1. Programoje pateikiama funkcija `canBeDividedIntoTriplets`, kuri priima masyvą ir tikrina, ar jis gali būti suskirstytas į tripletus su vienoda suma.
2. Funkcija apskaičiuoja bendrą visų skaičių sumą ir patikrina, ar ši suma yra daloma iš 3.
3. Kiekvienas tripletas bandomas suformuoti naudojant **kiekvieną** didžiausią ir mažiausią skaičius (pagal didėjimo tvarką), užtikrinant, kad jų suma atitiktų tikslinę reikšmę.
4. Jei tripletų skaičius yra teisingas, programos išveda tripletus ir jų sumas.

## **Pavyzdys:**
### **Įvestis:**
```c
int nums[] = {130, 40, 70, 120, 50, 70, 110, 60, 70, 100, 90, 50};
```

### **Išvestis:**
```
Skaiciu rinkinys: 130 40 70 120 50 70 110 60 70 100 90 50 
Nariu skaicius : 12
(130, 40, 50) -> 220
(120, 60, 50) -> 220
(110, 70, 40) -> 220
(100, 70, 50) -> 220
Taip, galima suskirstyti i trejetus su vienoda suma.
```



## **Funkcijos:**
- `canBeDividedIntoTriplets(int *nums, int n)` – Tikrina, ar pateiktas skaičių masyvas gali būti suskirstytas į tripletus su lygiomis sumomis.
- **Pagrindinė funkcija (`main`)** – Inicijuoja programą ir išveda rezultatą.


