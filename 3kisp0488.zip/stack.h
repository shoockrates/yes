#ifndef STACK_H
#define STACK_H

#include <stdbool.h>

//Stack structure
typedef struct {
    int *data;
    int top;
    int capacity;
} Stack;

//Function prototypes
Stack* Stack_create(int capacity);
bool Stack_push(Stack *stack, int value);
int Stack_pop(Stack *stack, bool *success);
bool Stack_isEmpty(Stack *stack);
int Stack_count(Stack *stack);
void Stack_free(Stack *stack);

#endif // STACK_H
