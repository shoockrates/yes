#include "sandwich_shop.h"
#include "queue.h"
#include "stack.h"


int find_shop_loss_stack(int holder_count, int order_chance, int sandwich_count, int sandwich_period, int expiration_time, int sandwich_price, int day_length)
{
    Stack *holders[100];
    int sandwich_cooldown, wasted_sandwich_count, money_loss;

    sandwich_cooldown = wasted_sandwich_count = 0;

    if(holder_count <= 0)
    {
        return 1;
    }

    for(int i = 0; i < holder_count; ++i)
    {
        holders[i] = Stack_create(sandwich_count * 4);
    }

    for(int time = 0; time < day_length; ++time)
    {
        if(sandwich_cooldown <= 0)
        {
            insert_sandwiches_stack(holders, holder_count, sandwich_count, time);

            sandwich_cooldown = sandwich_period;
        }
        --sandwich_cooldown;

        if(rand() % order_chance == 0)
        {
            buy_sandwich_stack(holders, holder_count);
        }
    }

    for(int i = 0; i < holder_count; ++i)
    {
        for(int j = 0; j < Stack_count(holders[i]); ++j)
        {
            if(expiration_time < day_length - holders[i]->data[j])
            {
                ++wasted_sandwich_count;
            }
        }
    }

    for(int i = 0; i < holder_count; ++i)
    {
        Stack_free(holders[i]);
    }

    money_loss = wasted_sandwich_count * sandwich_price;

    return money_loss;
}


void insert_sandwiches_stack(Stack *holders[], int holder_count, int sandwich_count, int time)
{
    Stack *least_sandwich_holder;

    least_sandwich_holder = holders[0];

    for(int i = 1; i < holder_count; ++i)
    {
        if(Stack_count(holders[i]) < Stack_count(least_sandwich_holder))
        {
            least_sandwich_holder = holders[i];
        }
    }

    for(int i = 0; i < sandwich_count; ++i)
    {
        Stack_push(least_sandwich_holder, time);
    }
}


void buy_sandwich_stack(Stack *holders[], int holder_count)
{
    int random_holder_id;
    Stack *temp_holder;

    random_holder_id = rand() % holder_count;

    for(int i = 0; i < holder_count; ++i)
    {
        temp_holder = holders[(i + random_holder_id) % holder_count];

        if(!Stack_isEmpty(temp_holder))
        {
            Stack_pop(temp_holder, 0);
            return;
        }
    }
}


int find_shop_loss_queue(int holder_count, int order_chance, int sandwich_count, int sandwich_period, int expiration_time, int sandwich_price, int day_length)
{
    Queue *holders[100];
    int sandwich_cooldown, wasted_sandwich_count, money_loss;

    sandwich_cooldown = wasted_sandwich_count = 0;

    if(holder_count <= 0)
    {
        return 1;
    }

    for(int i = 0; i < holder_count; ++i)
    {
        holders[i] = create_queue();
    }

    for(int time = 0; time < day_length; ++time)
    {
        if(sandwich_cooldown <= 0)
        {
            insert_sandwiches_queue(holders, holder_count, sandwich_count, time);

            sandwich_cooldown = sandwich_period;
        }
        --sandwich_cooldown;

        if(rand() % order_chance == 0)
        {
            buy_sandwich_queue(holders, holder_count);
        }
    }

    for(int i = 0; i < holder_count; ++i)
    {
        for(int j = 0; j < (int) holders[i]->size; ++j)
        {
            if(expiration_time < day_length - holders[i]->array[j])
            {
                ++wasted_sandwich_count;
            }
        }
    }

    for(int i = 0; i < holder_count; ++i)
    {
        free_queue(holders[i]);
    }

    money_loss = wasted_sandwich_count * sandwich_price;

    return money_loss;
}


void insert_sandwiches_queue(Queue *holders[], int holder_count, int sandwich_count, int time)
{
    Queue *least_sandwich_holder;

    least_sandwich_holder = holders[0];

    for(int i = 1; i < holder_count; ++i)
    {
        if(holders[i]->size < least_sandwich_holder->size)
        {
            least_sandwich_holder = holders[i];
        }
    }

    for(int i = 0; i < sandwich_count; ++i)
    {
        enqueue(least_sandwich_holder, time);
    }
}


void buy_sandwich_queue(Queue *holders[], int holder_count)
{
    int random_holder_id;
    Queue *temp_holder;

    random_holder_id = rand() % holder_count;

    for(int i = 0; i < holder_count; ++i)
    {
        temp_holder = holders[(i + random_holder_id) % holder_count];

        if(!is_empty(temp_holder))
        {
            dequeue(temp_holder);
            return;
        }
    }
}

